NF resize 1.8

Created by g_dori
KR server fscoolxi / Global server fv304

[한국어]
실행 환경: Windows 10/11 64비트, .NET Framework 4.x. 게임 연결 시 NAVYFIELD는 창모드여야 합니다. 원본 게임 화면 전체가 작업표시줄을 제외한 한 모니터의 작업 영역에 들어가야 합니다.
NF resize 1.8.exe 하나로 실행합니다. 별도 DLL이나 Python은 필요하지 않습니다.

1. EXE를 실행하세요. 관리자 권한 확인 창이 나오면 허용하세요. 게임이 없으면 100% 기준의 빈 화면(1024×768)으로 열립니다. 화면이 작으면 작업 영역에 맞춰 크기를 제한합니다. 게임을 창모드로 켠 뒤 상단 Reconnect(재연결) 버튼을 누르세요. 이미 실행 중인 게임이 있으면 바로 연결하며 초기 배율은 100%입니다.
2. 배율 버튼 또는 Fit을 선택하세요. 숫자 칸에 1~999를 입력하고 Enter/Apply를 누르면 해당 %가 적용됩니다. 창 크기에 따라 적용 가능한 배율은 제한됩니다.
3. 비율 메뉴에서 4:3·16:9·16:10·21:9를 선택하세요. 기본값은 네이비필드 기본 비율인 4:3입니다. 비율 변경은 화면 모양을 바꾸며 게임 시야를 넓히지는 않습니다.
   게임 화면을 클릭하면 조작이 시작되고 마우스 이동 범위가 제한됩니다.
4. NF resize 또는 연결된 게임이 활성화되어 있을 때 Alt+Enter로 전체화면을 전환합니다. Full screen 버튼도 사용할 수 있습니다.
5. Alt+Tab으로 다른 앱으로 이동하면 마우스 제한이 해제됩니다. 전체화면이었다면 직전 창 크기·위치로 돌아가고, 다시 활성화하면 전체화면으로 복귀합니다. 창모드였다면 마우스가 해제된 상태로 돌아오므로 화면을 클릭해 조작을 재개하세요.
6. 종료하면 원본 게임 창의 설정과 위치가 복구됩니다.
7. 게임을 재시작했다면 창모드로 게임을 켠 뒤 상단 Reconnect 버튼을 누르세요. 기존 배율·화면비를 유지하며 새 게임에 연결합니다. 화면을 클릭하면 조작을 다시 시작합니다. 게임이 종료되면 전체화면을 해제하고 재연결 안내를 표시합니다.

[English]
Requirements: 64-bit Windows 10/11 and .NET Framework 4.x. NAVYFIELD must be in windowed mode when connecting. The original game image must fit within the desktop work area of one monitor, excluding the taskbar.
Run NF resize 1.8.exe by itself. No separate DLL or Python installation is needed.

1. Run the EXE and accept the administrator prompt if shown. Without a game, a blank window opens at 100% (1024 x 768), limited to the desktop work area if necessary. Start NAVYFIELD in windowed mode, then click Reconnect. An already running game connects immediately; the initial scale is 100%.
2. Select a scale button or Fit. Enter 1–999 and press Enter/Apply to set that percentage. Available window space limits the applied scale.
3. Choose 4:3, 16:9, 16:10, or 21:9. The default is NAVYFIELD's standard 4:3 ratio. Changing the ratio reshapes the image without extending the game view.
   Click the game image to play and confine the pointer.
4. Press Alt+Enter while NF resize or its connected game is active to toggle full screen, or use Full screen.
5. Alt+Tab releases the pointer. A full-screen session returns to its previous window size and position, then resumes full screen when reactivated. A windowed session returns with the pointer unlocked; click the image to play again.
6. Closing the app restores the original game window settings and position.
7. After restarting the game in windowed mode, click Reconnect on the toolbar. The current scale and aspect ratio are preserved. Click the image to play again. When the game closes, NF resize exits full screen and shows reconnect instructions.

[日本語]
動作環境：64ビット版Windows 10/11、.NET Framework 4.x。接続するNAVYFIELDはウィンドウモードで起動してください。元のゲーム画面全体が、タスクバーを除く1台のモニターの作業領域に収まる必要があります。
NF resize 1.8.exeだけで実行できます。別途DLLやPythonのインストールは不要です。

1. EXEを実行し、管理者権限の確認が出たら許可してください。ゲームがない場合は100%基準の空画面（1024×768）が開きます。画面が小さい場合は作業領域に合わせて制限します。ゲームをウィンドウモードで起動してからReconnectを押してください。起動済みのゲームには自動で接続し、初期倍率は100%です。
2. 倍率ボタンまたはFitを選択します。数値欄に1〜999を入力しEnter/Applyを押すと、その%が適用されます。ウィンドウに収まる範囲で倍率が制限されます。
3. 比率は4:3・16:9・16:10・21:9から選べます。初期値はNAVYFIELDの標準比率4:3です。比率の変更は画面の形を変えるもので、ゲームの視野は広がりません。
   ゲーム画面をクリックすると操作が始まり、マウスの移動範囲が制限されます。
4. NF resizeまたは接続中のゲームがアクティブなとき、Alt+Enterで全画面を切り替えます。Full screenボタンも使えます。
5. Alt+Tabで別のアプリへ移るとマウスの制限が解除されます。全画面だった場合は直前のウィンドウサイズ・位置に戻り、再びアクティブにすると全画面に復帰します。ウィンドウモードだった場合は制限を解除したまま戻るので、画面をクリックして操作を再開してください。
6. 終了すると元のゲームウィンドウの設定と位置が復元されます。
7. ゲームをウィンドウモードで再起動したら、上部のReconnectを押してください。倍率と画面比率を維持して新しいゲームに接続します。画面をクリックすると操作を再開します。ゲーム終了時は全画面を解除し、再接続の案内を表示します。
